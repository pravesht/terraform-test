import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

def lambda_handler(event, context):
    operation = event['pathParameters']['operation']
    
    if operation == 'create':
        return create_item(event)
    elif operation == 'read':
        return read_item(event)
    elif operation == 'update':
        return update_item(event)
    elif operation == 'delete':
        return delete_item(event)
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('Unsupported operation')
        }

def create_item(event):
    data = json.loads(event['body'])
    table.put_item(Item=data)
    return {
        'statusCode': 200,
        'body': json.dumps('Item created successfully')
    }

def read_item(event):
    key = json.loads(event['body'])
    response = table.get_item(Key=key)
    return {
        'statusCode': 200,
        'body': json.dumps(response.get('Item', 'Item not found'))
    }

def update_item(event):
    data = json.loads(event['body'])
    key = {'id': data['id']}
    update_expression = "set info=:i"
    expression_attribute_values = {':i': data['info']}
    table.update_item(Key=key, UpdateExpression=update_expression,
                      ExpressionAttributeValues=expression_attribute_values)
    return {
        'statusCode': 200,
        'body': json.dumps('Item updated successfully')
    }

def delete_item(event):
    key = json.loads(event['body'])
    table.delete_item(Key=key)
    return {
        'statusCode': 200,
        'body': json.dumps('Item deleted successfully')
    }
