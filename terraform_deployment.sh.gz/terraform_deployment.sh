#!/bin/bash

# Define variables
TF_DIR="/path/to/terraform/directory"
TF_VARS_FILE="terraform.tfvars"
PLAN_FILE="tfplan"

# Navigate to the Terraform directory
cd "$TF_DIR" || exit 1

# Initialize Terraform
echo "Initializing Terraform..."
terraform init

# Validate Terraform files
echo "Validating Terraform configuration..."
terraform validate

# Generate a plan
echo "Generating Terraform plan..."
terraform plan -var-file="$TF_VARS_FILE" -out="$PLAN_FILE"

# Apply the plan
read -p "Do you want to apply this plan? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]
then
    echo "Applying Terraform plan..."
    terraform apply "$PLAN_FILE"
else
    echo "Terraform apply aborted."
    exit 1
fi

# Output the state
echo "Displaying current state..."
terraform show

