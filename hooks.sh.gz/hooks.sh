#!/bin/bash

# Set paths for terraform and tflint (if installed globally)
TERRAFORM=$(which terraform)
TFLINT=$(which tflint)

# Check for terraform and tflint installation
if [ -z "$TERRAFORM" ] || [ -z "$TFLINT" ]; then
  echo "Terraform and/or tflint not installed. Please install them before committing."
  exit 1
fi

# Format check
echo "Checking Terraform formatting..."
if ! terraform fmt -check -recursive; then
  echo "Terraform formatting errors detected."
  exit 1
fi

# Validate check
echo "Validating Terraform configuration..."
if ! terraform validate; then
  echo "Terraform validation errors detected."
  exit 1
fi

# Lint check
echo "Linting Terraform files..."
if ! tflint; then
  echo "Terraform linting errors detected."
  exit 1
fi

echo "Pre-commit checks passed."

